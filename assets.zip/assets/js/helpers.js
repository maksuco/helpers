//THIS IS FOR REGULAR PHP CLIENTS
// @codekit-prepend "/vendor/maksuco/helpers/assets/packages/alpine/alpinev3.js";
// @codekit-prepend "/vendor/maksuco/helpers/assets/packages/apexcharts/apexcharts.min.js";
// @codekit-prepend "/vendor/maksuco/helpers/assets/packages/flickity/flickity.js";
// @codekit-prepend "/vendor/maksuco/helpers/assets/packages/highlights/highlights.js";
// @codekit-prepend "/vendor/maksuco/helpers/assets/packages/moment/moment-with-locales.js";
// @codekit-prepend "/vendor/maksuco/helpers/assets/packages/numeral/numeral.min.js";
// @codekit-prepend "/vendor/maksuco/helpers/assets/packages/plyr/dist/plyr.min.js";
// @codekit-prepend "/vendor/maksuco/helpers/assets/packages/pikaday.js";
// @codekit-prepend "/vendor/maksuco/helpers/assets/packages/cleave.js";
// @codekit-prepend "/vendor/maksuco/helpers/assets/packages/tinycolor.js";

//FUNCTIONS
// @codekit-prepend "/vendor/maksuco/helpers/assets/js/functions.js";